
using System;

namespace _03_evento
{
    class ComidaBuffet : Evento
    {
        int comid;
        public int EleccionComidas{
            get{
                return comid;
            }
            set{
                switch(value){
                    case 1:
                        comid = 1;
                        Console.WriteLine("Tenemos una gran variedad de comidas para el evento");
                        break;
                    default:
                        Console.WriteLine("Ingresó un valor inválido para el Elección de decoración");
                        comid = 0;
                        break;
                }
            }
        }
        public string Comidas(){

            string mensaje = "";
            
            if(EleccionComidas == 1){
                int c = 1;
                
                while(c != 0){
                    Console.WriteLine("Por favor elija el tipo de comida para el evento (Mariscos = 1, Carnes = 2, Vegano = 3): ");
                    int eleccionComidas = int.Parse(Console.ReadLine());

                    if(eleccionComidas == 1){
                        mensaje = "Ha elegido Mariscos";
                        c = 0;
                    }else if(eleccionComidas == 2){
                        mensaje = "Ha elegido Carnes";
                        c = 0;
                    }else if(eleccionComidas == 3){
                        mensaje = "Ha elegido Vegano";
                        c = 0;
                    }else{
                        Console.WriteLine("No eligió una opción válida");
                        c = 1;
                    }
                }
            }
            return mensaje;
        }
    }
}