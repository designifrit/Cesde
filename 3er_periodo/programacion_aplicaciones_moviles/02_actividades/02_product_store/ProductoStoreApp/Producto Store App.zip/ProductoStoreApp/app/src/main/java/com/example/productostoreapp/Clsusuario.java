package com.example.productostoreapp;

public class Clsusuario {
    private String producto;
    private String descripcion;
    private Number existencias;
    private Number valor;

    public Clsusuario() {
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Number getExistencias() {
        return existencias;
    }

    public void setExistencias(Number existencias) {
        this.existencias = existencias;
    }

    public Number getValor() {
        return valor;
    }

    public void setValor(Number valor) {
        this.valor = valor;
    }
}
