package com.example.productostoreapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RegistrarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
    }
}